import Exercise1 (_main)
import Exercise2 (_main)
import Exercise3 (_main)
import Exercise4 (_main)
import Exercise5 (_main)
import Exercise6 (_main)
import Exercise7 (_main)

main :: IO ()
main = do
  Exercise1._main
  Exercise2._main
  Exercise3._main
  Exercise4._main
  Exercise5._main
  Exercise6._main
  Exercise7._main

  putStrLn "\n\n✨ All Done! ✨"

